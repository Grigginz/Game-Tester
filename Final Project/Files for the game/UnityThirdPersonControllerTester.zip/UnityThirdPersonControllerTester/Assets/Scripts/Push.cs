using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Push : MonoBehaviour
{
    [SerializeField] Transform ball;

    private void Start()
    {

    }

    private void Update()
    {

    }

    
    
    
    
}
